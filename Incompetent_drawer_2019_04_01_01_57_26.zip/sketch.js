function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(220);
}

beginShape();
rect(27,30.211,99.474,335.263);
fill(237,28,36);
beginShape();
rect(27,310,398.737,310,62.105);
fill(0,166,81);
endShape(CLOSE);

beginShape();
rect(145.947,197.842,137.895,172.368);
fill(255,242,0);
endShape(CLOSE);

beginShape();
rect(145.947,30.211,328.421,147.368);
fill(241,90,41);
endShape(SHAPE);

beginShape();
rect(310.158,200.395,164.211,99.211);
fill(117,76,41);
endShape(CLOSE);
